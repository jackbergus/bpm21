input:
 - ex_1.txt: Modello Declare DataAware (sintassi simil-paper)
 - log_1.txt: Tracce DataAware da allineare contro il modello (sintassi simil-paper)
 
output:
 - eq_classes_1.txt: Input di classi di equivalenza che servono ad Andrea per le Replace
 - log_1.txt.xes: Rappresentazione XES del modello di input
 - log_atomized_1.txt: Rappresentazione human-readable delle tracce convertite dal log in input (sintassi simil-paper)
 - log_atomized_1.xes: Rappresentazione XES delle tracce convertite dal log in input 
 - graph_1.dot: Automa generato a partire dal Modello Declare DataAware
 
In questa cartella, graph_1.pdf è la rappresentazione pdf del .dot fornito in output gramite GraphViz.
